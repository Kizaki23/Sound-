package com.example.sound

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
