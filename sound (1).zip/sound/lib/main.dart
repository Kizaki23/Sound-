import 'dart:math';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lachica, Kristine G',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  List<String> boxLabels = ['Box 1', 'Box 2', 'Box 3', 'Box 4', 'Box 5', 'Box 6'];
  List<String> soundFiles = [
    'assets/sound_1.mp3',
    'assets/sound_2.mp3',
    'assets/sound_3.mp3',
    'assets/sound_4.mp3',
    'assets/sound_5.mp3',
    'assets/sound_6.mp3',
  ];

  final AudioPlayer _audioPlayer = AudioPlayer();
  String currentSound = ''; // Variable to store the name of the current sound

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lachica, Kristine G'),
      ),
      body: Column(
        children: [
          // Displaying the current randomized sound
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text(
              currentSound.isEmpty
                  ? 'Randomized Sound: None'
                  : 'Randomized Sound: $currentSound',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(20),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 20,
                mainAxisSpacing: 20,
              ),
              itemCount: boxLabels.length,
              itemBuilder: (context, index) {
                return ElevatedButton(
                  onPressed: () {
                    _playSound(index);
                  },
                  child: Text(boxLabels[index]),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: ElevatedButton(
              onPressed: () {
                _shuffleBoxesAndSounds(); // Shuffle both boxes and sounds
              },
              child: Text('Randomize'),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 50), // Full width button
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _shuffleBoxesAndSounds() {
    setState(() {
      boxLabels.shuffle(Random.secure());
      soundFiles.shuffle(Random.secure()); // Shuffle the sounds as well
    });
  }

  void _playSound(int index) async {
    if (index < soundFiles.length) {
      setState(() {
        // Update currentSound to show "Sound X" based on the index
        currentSound = 'Sound ${index + 1}'; // Show sound name like "Sound 1"
      });
      await _audioPlayer.play(soundFiles[index]); // Play the shuffled sound
    }
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }
}
